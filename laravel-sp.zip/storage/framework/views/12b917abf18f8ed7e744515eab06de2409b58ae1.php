<?php $__env->startSection('title-page'); ?>
Drama <?php echo e($result->title); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12">
        <div class="page-header">
            <?php echo e($result->title); ?> [<?php echo e($result->id); ?>] 
        </div>
        <div class="panel panel-primary">
            <div class="panel-heading"><?php echo e($result->title); ?> Command Action</div>
            <div class="panel-body">
                <div class="alert alert-danger alert-dismissible" id="alert-danger" style="display:none">
                </div>
                <div class="alert alert-success alert-dismissible" id="alert-succes" style="display:none">
                </div>
                <!-- Button trigger modal -->
                <button type="button" id="btnModal" onclick="btnAdd()" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#modelId">
                    <i class="fa fa-plus fa-fw"></i> Drama Eps.
                </button>
                <button type="button" id="btnReloadTable" onclick="btnReloadTable()" class="btn btn-primary btn-sm">
                    <i class="fa fa-refresh fa-fw"></i> Reload Table
                </button>
                <button type="button" id="btnSingkron" onclick="btnSingkron()" class="btn btn-primary btn-sm">
                    <i class="fa fa-refresh fa-fw"></i> Singkron Folder
                </button>
                <button type="button" id="btnSingkronWeb" data-title="<?php echo e($result->title); ?>" class="btn btn-primary btn-sm">
                        <i class="fa fa-refresh fa-fw"></i> Singkron Wordpress
                </button>
                <!-- Modal -->
                    <div class="modal fade" id="modelId" tabindex="-1" role="dialog" aria-labelledby="modelTitleId" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <form action="<?php echo e(route("epsPost", $result->id)); ?>" method="post" id="formDrama" role="form">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                    <h4 class="modal-title" id="modelTitleId">Drama</h4>
                                </div>
                                <div class="modal-body">
                                    <div class="container-fluid">
                                            <input type="hidden" name="id" id="id" hidden>
                                            <input type="hidden" name="drama_id" id="drama_id" hidden>
                                            <?php echo e(csrf_field()); ?>

                        
                                            <div class="form-group">
                                                <label class="control-label" for="email">Name</label>
                                                <input type="text" class="form-control" name="title" id="title" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="type" class="form-label">Status</label>
                                                <select class="custom-select form-control" name="status" id="status" required>
                                                    <option value="Hardsub" selected>Hardsub</option>
                                                    <option value"SUB">SUB</option>
                                                </select>
                                            </div>
                                            <div class="form-group">
                                                <label class="control-label" for="email">Link 720p</label>
                                                <input type="text" class="form-control" name="f720p" id="f720p" >
                                            </div>
                                            <div class="form-group">
                                                <label class="control-label" for="email">Link 360p</label>
                                                <input type="text" class="form-control" name="f360p" id="f360p" >
                                            </div>
                                            
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    <button type="reset" class="btn btn-danger">Reset</button>
                                    <button type="submit" class="btn btn-primary">Save</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div id='content' >
        </div>
        <table class="table table-striped table-bordered table-hover dataTable no-footer dtr-inline" style="width:100%" id="table-users">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Title</th>
                    <th>Status</th>
                    <th>720p</th>
                    <th>360p</th>
                    <th>Action</th>
                </tr>
            </thead>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<script type="text/javascript">
    $(document).ready(function(){
        $( "#table-users" ).on( "click", "#btnShow" , function() {
            event.preventDefault()
            $('#modelId').modal('show');
            $("#formDrama")[0].reset()
            $("input[name=id]").val($(this).attr('data-id')) ;
            $("input[name=drama_id]").val($(this).attr('data-drama_id')) ;
            $("input[name=title]").val($(this).attr('data-title'));
            $("select[name=status]").val($(this).attr('data-status'));
            $("input[name=f720p]").val($(this).attr('data-f720p'));
            $("input[name=f360p]").val($(this).attr('data-f360p'));
        });
        $("#btnSingkronWeb").on("click", function(){
            event.preventDefault()

            var seacrh = $(this).attr("data-title");
            $.ajax({
                type:"get",
                url: "<?php echo e(route('webfrontSingkron')); ?>",
                success: function(data){
                    $("#content").html(data);
                    $("input[name=searchKeyword]").val(seacrh) ;

                }
            });
        });
        
        $("#formDrama").on("submit",function(){
            event.preventDefault()
            $.ajax({
                type:"post",
                url: "<?php echo e(route('epsPost', $result->id)); ?>",
                data: $( this ).serializeArray(),
                success: function(data){
                    $(".alert-success").fadeIn().html(data).wait(20000).fadeOut('slow');
                    $("#table-users").DataTable().ajax.reload(null, false);
                    $("#formDrama")[0].reset()
                    $('#modelId').modal('hide');
                    $(".alert-success").fadeOut(20000);

                },
                error: function(data){
                    $(".alert-success").fadeIn().html(data).wait(20000).fadeOut('slow');

                    $("#table-users").DataTable().ajax.reload(null, false);
                    $("#formDrama")[0].reset()
                    $('#modelId').modal('hide');
                    $(".alert-danger").fadeOut(20000);

                }
            });
        
        });

        $("#content").on("click",'#btnSubmitSingkron',function(){
            event.preventDefault()
            var siteId = $('#siteid').val();
            var searchKeyword = $('#searchKeyword').val();
            var drama_id = '<?php echo e($result->id); ?>';
            $.ajax({
                type:"POST",
                url: "<?php echo e(route('webfrontSingkronpost')); ?>",
                data: {"id":siteId,"seacrh":searchKeyword},
                success: function(data){
                    $('#contentSearch').html(data);
                }
            });      
  
        });
        $( "#table-users" ).on( "click", "#btnDelete" , function() {
            var fn = $(this).attr('data-title');
            if (confirm('Are you sure you want to delete '+ fn +'?')) {
                $.ajax({
                    url: "<?php echo e(route('epsDelete',$result->id)); ?>",
                    type: "delete",
                    data: {
                        id: $(this).attr('data-id')
                    },
                    success: function(data){
                        $(".alert-success").fadeIn().html('Delete User '+fn+' success').wait(20000).fadeOut('slow');
                        $("#table-users").DataTable().ajax.reload(null, false);
                        $(".alert-success").fadeOut(20000);

                    },
                    error: function(data){
                        $(".alert-success").fadeIn().html('Delete User '+fn+' Failed').wait(20000).fadeOut('slow');
                        $("#table-users").DataTable().ajax.reload(null, false);
                        $(".alert-danger").fadeOut(20000);

                    }
                });
            }
        });
        $("#table-users").ready(function(){
            var oTable = $("#table-users").DataTable({
                "processing": true,
                "serverSide": true,
                "ajax": "<?php echo e(route('epsData',$result->id)); ?>",
                "columns": [
                    {data: 'id', name: 'id'},
                    {data: 'title', name: 'title'},
                    {data: 'status', name: 'status'},
                    {data: 'f720p', name: 'f720p'},
                    {data: 'f360p', name: 'f360p'},
                    {data: 'action', name: 'action', orderable: false, searchable: false}
                ],
               
            });
        });
    });
    function btnAdd() { 
        $("#formDrama")[0].reset()
        $("input[name=drama_id]").val('<?php echo e($result->id); ?>') ;
        $("input[name=title]").val('<?php echo e($result->title); ?> E') ;
    };
    function btnSingkronToweb(idPost,titlePost) { 
        event.preventDefault()
        var siteId = $('#siteid').val();
        var siteName = $('#siteid').find('option:selected').text();
        var searchKeyword = $('#searchKeyword').val();
        var drama_id = '<?php echo e($result->id); ?>';
        $.ajax({
            type:"POST",
            url: "<?php echo e(route('webfrontSingkronpost')); ?>/"+siteId,
            data: {"drama_id":drama_id,"idPost":idPost},
            success: function(data){
                data = JSON.parse(data);
                if(data.id){
                    $(".alert-success").fadeIn().html("<a href='"+data.link+"' target='_blank'>"+data.title.rendered+" "+siteName+"</a>").wait(20000).fadeOut('slow');
                }else{
                    $(".alert-danger").fadeIn().html(data.massage).wait(20000).fadeOut('slow');
                }
            }
        });  
    };
    function btnReloadTable(){
        $(".alert-success").fadeIn().html('Reload Success').wait(20000).fadeOut('slow');
    }
    jQuery.fn.wait = function (MiliSeconds) {
        $(this).animate({ opacity: '+=0' }, MiliSeconds);
        return this;
    }
    function btnSingkron(){
        $.ajax({
                    url: "<?php echo e(route('driveEps',$result->id)); ?>",
                    type: "get",
                    success: function(data){
                        $("#content").fadeOut(function(){
                            setTimeout(function(){
                                $("#content").fadeIn().html(data).wait(20000).fadeOut('slow');
                            },1000);
                        }) 
                    }
        });    
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('parts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>