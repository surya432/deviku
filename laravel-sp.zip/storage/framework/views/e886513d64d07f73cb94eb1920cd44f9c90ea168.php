<?php $__env->startSection('content'); ?>

<div class="row">

    <div class="col-lg-12">

        <h1 class="page-header">Add User</h1>

    </div>
    <div class="col-lg-12 col-md-12">
        <div class="panel panel-primary">
            <div class="panel-heading">
                    <h3 class="panel-title">User Detail</h3>
            </div>
            <div class="panel-body">
                <form action="/admin/register" method="POST" role="form">
                    <?php if(session('alert')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('alert')); ?>

                        </div>
                    <?php endif; ?>
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <div class="form-group">
                            <label for="email" class="">Email</label>
                            <input type="email" name="email" class="form-control" id="email" placeholder="Your Email">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="form-group">
                            <label for="first-name" class="">First Name</label>
                            <input type="text" name="first_name" class="form-control" id="first-name" placeholder="First Name">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="form-group">
                            <label for="last-name" class="">Last Name</label>
                            <input type="text" name="last_name" class="form-control" id="last-name" placeholder="Last Name">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="form-group">
                            <label for="password" class="">Password</label>
                            <input type="password" name="password" class="form-control" id="password" placeholder="Password">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="form-group">
                            <label for="role_users">Access</label>
                            <select class="form-control" name="access" id="access">
                            <option value="admin">Admin</option>
                            <option value="editor">Editor</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <input type="submit" value="Submit" class="btn btn-success pull-right">
                        <input type="reset" value="Reset" class="btn btn-danger pull-right">
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- /.col-lg-12 -->

</div>
<!-- /.row -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('parts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>