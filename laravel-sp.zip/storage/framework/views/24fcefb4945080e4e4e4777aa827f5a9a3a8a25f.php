Result:
<div class="list-group">
    <?php if(!$url): ?>
        keyword not found
    <?php endif; ?>
    <?php $__currentLoopData = $url; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <a data-id="<?php echo e($post['id']); ?>" id="singkronPost" onclick="btnSingkronToweb('<?php echo e($post['id']); ?>','<?php echo e(str_replace('"', "",json_encode($post['title']['rendered']) )); ?>');" class="list-group-item list-group-item-action"><?php echo e(str_replace('"', "",json_encode($post['title']['rendered']) )); ?>

        </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>