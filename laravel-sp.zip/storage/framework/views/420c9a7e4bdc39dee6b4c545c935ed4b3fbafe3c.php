<div class="list-group">
    <?php if(!$url): ?>
        keyword not found
    <?php endif; ?>
    <ul>
        <?php $__currentLoopData = $url; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><a href="<?php echo e(route('viewEps',$url )); ?>" class="list-group-item list-group-item-action"><?php echo e($url); ?></a></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>