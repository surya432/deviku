<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        //$this->call(serialtv::class);
        //$this->call(ContentSeed::class);
        //$this->call(MirrorSeeder::class);
        //$this->call(GmailSeeder::class);
    }
}
